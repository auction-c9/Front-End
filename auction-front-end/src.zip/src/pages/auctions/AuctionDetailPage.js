import React, { useEffect, useState, useRef } from "react";
import { useParams } from "react-router-dom";
import { api } from "../../config/apiConfig";
import { useAuth } from "../../context/AuthContext";
import { formatCurrency, formatDateTime } from "../../utils/utils";

const AuctionDetailPage = () => {
    const { id } = useParams(); // ✅ Lấy auction id từ URL
    const { user } = useAuth(); // ✅ Lấy user từ context
    const socketRef = useRef(null); // ✅ Quản lý websocket

    const [auction, setAuction] = useState(null);
    const [bidHistory, setBidHistory] = useState([]);
    const [currentPrice, setCurrentPrice] = useState(0);
    const [highestBidder, setHighestBidder] = useState(null);

    // Fetch chi tiết phiên đấu giá
    const fetchAuctionDetails = async () => {
        try {
            const res = await api.get(`${api.auctions}/${id}`);
            setAuction(res.data);
            setCurrentPrice(res.data.currentPrice || res.data.startPrice);
            setHighestBidder(res.data.highestBidder);
        } catch (err) {
            console.error("Lỗi khi lấy chi tiết phiên đấu giá:", err);
        }
    };

    // Fetch lịch sử đấu giá
    const fetchBidHistory = async () => {
        try {
            const res = await api.get(`${api.bids}/auction/${id}`);
            setBidHistory(res.data);
        } catch (err) {
            console.error("Lỗi khi lấy lịch sử đấu giá:", err);
        }
    };

    // Kết nối WebSocket để cập nhật real-time
    const connectWebSocket = () => {
        socketRef.current = new WebSocket(`ws://localhost:8080/ws/auction/${id}`);
        socketRef.current.onmessage = (event) => {
            const message = JSON.parse(event.data);
            console.log("Thông báo từ server:", message);

            if (message.type === "NEW_BID") {
                setBidHistory((prev) => [message.data, ...prev]);
                setCurrentPrice(message.data.amount);
                setHighestBidder(message.data.user.fullName);
            }
        };
        socketRef.current.onclose = () => console.log("Ngắt kết nối WebSocket");
    };

    // useEffect gọi các hàm trên khi component mount
    useEffect(() => {
        fetchAuctionDetails();
        fetchBidHistory();
        connectWebSocket();

        return () => socketRef.current?.close();
    }, [id]);

    if (!auction) return <p>Đang tải thông tin phiên đấu giá...</p>;

    return (
        <div>
            <h2>Chi tiết phiên đấu giá: {auction.product.name}</h2>
            <p>Mô tả: {auction.product.description}</p>
            <p>Giá khởi điểm: {formatCurrency(auction.startPrice)}</p>
            <p>Giá hiện tại: {formatCurrency(currentPrice)}</p>
            <p>Người đấu giá cao nhất: {highestBidder || "Chưa có"}</p>

            <h3>Lịch sử đấu giá:</h3>
            {bidHistory.length === 0 ? (
                <p>Chưa có ai đấu giá.</p>
            ) : (
                <ul>
                    {bidHistory.map((bid) => (
                        <li key={bid.bidId}>
                            {bid.user.fullName} đã trả {formatCurrency(bid.amount)} lúc {formatDateTime(bid.bidTime)}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default AuctionDetailPage;
