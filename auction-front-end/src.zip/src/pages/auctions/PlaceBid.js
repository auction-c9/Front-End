import React, { useState } from "react";
import { api } from "../../config/apiConfig"; // import api từ file config

const PlaceBid = ({ auctionId, currentPrice, minBid, onBidSuccess }) => {
    const [bidAmount, setBidAmount] = useState("");
    const [error, setError] = useState("");

    const handleBidSubmit = async (e) => {
        e.preventDefault();
        const amount = parseFloat(bidAmount);
        if (isNaN(amount) || amount < currentPrice + minBid) {
            setError(`Giá đấu phải tối thiểu ${currentPrice + minBid} VND`);
            return;
        }
        try {
            const response = await api.post(`/auctions/${auctionId}/bid`, { amount }); // Gọi qua api config
            const data = response.data;
            onBidSuccess({
                type: "BID_UPDATE",
                currentPrice: data.currentPrice,
                highestBidder: data.highestBidder,
                bid: { bidderName: data.highestBidder, amount: data.currentPrice, time: new Date().toISOString() },
            });
            setBidAmount("");
            setError("");
        } catch (err) {
            console.error("Error placing bid:", err);
            setError(err.response?.data?.message || "Đấu giá thất bại.");
        }
    };

    return (
        <form onSubmit={handleBidSubmit} className="mt-3">
            <div className="input-group">
                <input
                    type="number"
                    className="form-control"
                    placeholder={`Tối thiểu ${currentPrice + minBid}`}
                    value={bidAmount}
                    onChange={(e) => setBidAmount(e.target.value)}
                    required
                />
                <button type="submit" className="btn btn-primary">Đặt giá</button>
            </div>
            {error && <small className="text-danger">{error}</small>}
        </form>
    );
};

export default PlaceBid;
